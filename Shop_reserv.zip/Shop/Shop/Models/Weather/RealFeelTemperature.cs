﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shop.Models.Weather
{
    public class RealFeelTemperature
    {
        public Minimum Minimum { get; set; }
        public Maximum Maximum { get; set; }
    }
}
