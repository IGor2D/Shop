﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shop.Models.Weather
{
    public class Direction
    {
        public double Degrees { get; set; }
        public string Localized { get; set; }
        public string English { get; set; }
    }
}
