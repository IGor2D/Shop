﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shop.Models.Weather
{
    public class Wind
    {
        public Speed Speed { get; set; }
        public Direction Direction { get; set; }
    }
}
