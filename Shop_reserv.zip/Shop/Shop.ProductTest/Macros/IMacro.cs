﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shop.ProductTest.Macros
{
    public interface IMacro
    {
    }
}
