﻿namespace Shop.Core.ServiceInterface
{
    public interface IApplicationService
    {
    }
}